# LifestyleStore
An Online Shopping website developed using Html, CSS, Bootstrap, MySQL, PHP.<br>
http://lifestore.000webhostapp.com/

Features
--------

* All forms validated on Client side using HTML5 and on Server side using PHP.
* Responsive and nice looking webpages 

Running the project 
-------------------

* Install WAMP
* Import database from store.sql file.
* Run WAMP and open web page from browser: http://localhost/LifestyleStore/index.php

Project Developer
----------------
Sajal Agrawal
